
# TP3 — Diagrammes de classes

## Étape 2 — Diagramme de l'existant

```mermaid
classDiagram
    class ReportService {
        -dbFile : URL
        -smtp : Object
        +outbox : Array
        +history : Array
        +ReportService()
        +loadOrders()
        +generate(month, format, recipient)
    }

    class FreeReportService {
        +generate(month, format, recipient)
    }

    ReportService <|-- FreeReportService

    class orders_json {
        <<fichier JSON>>
    }

    class Console {
        <<dépendance technique>>
        +log(message)
    }

    class SMTP {
        <<configuration e-mail>>
        +host : String
        +port : Number
        +user : String
        +password : String
    }

    ReportService ..> orders_json : lit les commandes
    ReportService ..> Console : écrit les journaux
    ReportService ..> SMTP : prépare les e-mails
```


## Étape 4 — Diagramme de classes après extraction

```mermaid
classDiagram
    class ReportService {
        -dbFile : URL
        -smtp : Object
        +outbox : Array
        +history : Array
        -csvFormatter : CsvFormatter
        +ReportService(options)
        +loadOrders()
        +generate(month, format, recipient)
    }

    class CsvFormatter {
        +format(stats)
    }

    class FreeReportService {
        +generate(month, format, recipient)
    }

    ReportService <|-- FreeReportService
    ReportService --> CsvFormatter : utilise par injection
    ReportService ..> orders_json : lit les commandes
    ReportService ..> Console : journalise
    ReportService ..> SMTP : prépare les e-mails
```

## Étape 4 — Diagramme de classes de la cible après refactoring complet

```mermaid
classDiagram
    class ReportService {
        -orderRepository : IOrderRepository
        -statisticsCalculator : IStatisticsCalculator
        -csvFormatter : IReportFormatter
        -htmlFormatter : IReportFormatter
        -jsonFormatter : IReportFormatter
        -logger : ILogger
        -emailSender : IEmailSender
        +generate(month, format, recipient)
    }

    class IOrderRepository {
        <<interface>>
        +loadOrders()
    }

    class IStatisticsCalculator {
        <<interface>>
        +calculate(orders)
    }

    class IReportFormatter {
        <<interface>>
        +format(stats)
    }

    class ILogger {
        <<interface>>
        +log(message)
    }

    class IEmailSender {
        <<interface>>
        +send(recipient, subject, body)
    }

    class JsonOrderRepository {
        +loadOrders()
    }

    class StatisticsCalculator {
        +calculate(orders)
    }

    class CsvFormatter {
        +format(stats)
    }

    class HtmlFormatter {
        +format(stats)
    }

    class JsonFormatter {
        +format(stats)
    }

    class ConsoleLogger {
        +log(message)
    }

    class SmtpEmailSender {
        -host : String
        -port : Number
        +send(recipient, subject, body)
    }

    IOrderRepository <|.. JsonOrderRepository
    IStatisticsCalculator <|.. StatisticsCalculator
    IReportFormatter <|.. CsvFormatter
    IReportFormatter <|.. HtmlFormatter
    IReportFormatter <|.. JsonFormatter
    ILogger <|.. ConsoleLogger
    IEmailSender <|.. SmtpEmailSender

    ReportService --> IOrderRepository : lit les commandes
    ReportService --> IStatisticsCalculator : calcule les indicateurs
    ReportService --> IReportFormatter : formate le rapport
    ReportService --> ILogger : journalise
    ReportService --> IEmailSender : envoie le rapport
```
