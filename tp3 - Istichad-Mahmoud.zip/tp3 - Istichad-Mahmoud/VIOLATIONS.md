Étape 1 — Tableau des violations

1. Principe : SRP (Responsabilité unique)

Emplacement : classe ReportService, méthodes loadOrders() et generate().

Problème : la classe lit les commandes, calcule les indicateurs, génère les rapports, écrit des logs et prépare les e-mails.

Conséquence : une modification d'une responsabilité peut affecter les autres.
2. Principe : OCP (Ouvert/Fermé)

Emplacement : méthode generate(), conditions if / else sur le format.

Problème : ajouter un nouveau format oblige à modifier cette méthode.

Conséquence : cela augmente le risque de régression.

3. Principe : LSP (Substitution de Liskov)

Emplacement : méthode generate() de FreeReportService.

Problème : la classe fille refuse certains formats et l'envoi par e-mail autorisés par la classe mère.

Conséquence : remplacer ReportService par FreeReportService peut provoquer des erreurs.
4. Principe : DIP (Inversion des dépendances)

Emplacement : import de node:fs et constructeur de ReportService.

Problème : la classe dépend directement du système de fichiers et configure elle-même le SMTP.

Conséquence : remplacer ces dépendances ou tester la classe indépendamment devient plus difficile.

5. Principe : ISP (Ségrégation des interfaces)

Emplacement : organisation générale de ReportService.

Problème : plusieurs responsabilités sont regroupées dans une seule classe. Toutefois, une violation directe de l'ISP n'est pas clairement démontrée par le code.

Conséquence : les utilisateurs de la classe peuvent dépendre de fonctionnalités dont ils n'ont pas besoin.

2. Analyse Cyber

A. Secret SMTP dans le code

Emplacement : constructeur, propriété this.smtp.

Risque : le mot de passe peut être exposé si le code est partagé ou publié.

Correction : utiliser une variable d'environnement ou un gestionnaire de secrets, et renouveler tout secret réel qui aurait été exposé.

B. Journaux

Emplacement : méthode generate(), appel à console.log().

Risque : les journaux révèlent des informations sur l'activité commerciale.

Correction : limiter les informations enregistrées et contrôler l'accès aux journaux.
C. Validation de l'adresse e-mail

Emplacement : condition !recipient.includes('@').

Risque : la présence de @ ne garantit pas qu'une adresse est valide.

Correction : effectuer une validation plus fiable avant l'envoi.

D. Champs publics

Emplacement : propriétés this.smtp et this.outbox.

Risque : d'autres parties du programme peuvent accéder à ces données ou les modifier.

Correction : protéger les données sensibles et éviter d'exposer le mot de passe SMTP.

